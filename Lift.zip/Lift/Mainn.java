package pack;
//Example usage of the building
public class Mainn {
 public static void main(String[] args) {
     Building.createBuilding();
 }
}
