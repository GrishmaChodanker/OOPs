package pack;

//Define a class for a lift
class Lift {
 private int currentFloor;
 private boolean directionUp;

 // Constructor to initialize the lift properties
 public Lift() {
     currentFloor = 1; // lift starts at the ground floor
     directionUp = true; // lift starts moving up
 }

 // Method to move the lift up one floor
 public void moveUp() {
     if (currentFloor < Building.NUM_FLOORS) {
         currentFloor++;
         System.out.println("Lift moving up to floor " + currentFloor);
     } else {
         System.out.println("Already on top floor");
     }
 }

 // Method to move the lift down one floor
 public void moveDown() {
     if (currentFloor > 1) {
         currentFloor--;
         System.out.println("Lift moving down to floor " + currentFloor);
     } else {
         System.out.println("Already on ground floor");
     }
 }

 // Method to open the lift doors
 public void openDoors() {
     System.out.println("Lift doors opening");
 }

 // Method to close the lift doors
 public void closeDoors() {
     System.out.println("Lift doors closing");
 }
 public int getCurrentFloor() {
	  return currentFloor;
	}

}