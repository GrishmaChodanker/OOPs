package pack;

class Floor {
    private int floorNumber;

    // Constructor to initialize the floor properties
    public Floor(int floorNumber) {
        this.floorNumber = floorNumber;
    }

    // Method to get the floor number
    public int getFloorNumber() {
        return floorNumber;
    }
}
