package pack;

//Define a class for the building
class Building {
 public static final int NUM_FLOORS = 10;

 // Method to create the lift and floors
 public static void createBuilding() {
     Lift lift = new Lift();
     Floor[] floors = new Floor[NUM_FLOORS];
     for (int i = 0; i < NUM_FLOORS; i++) {
         floors[i] = new Floor(i + 1);
     }

     // Example usage of the lift and floors
     lift.moveUp(); // move the lift up one floor
     lift.openDoors(); // open the lift doors
     lift.closeDoors(); // close the lift doors
     lift.moveDown(); // move the lift down one floor
     System.out.println("Current floor: " + lift.getCurrentFloor()); // print the current floor
     lift.moveUp();
     lift.moveUp();
     System.out.println("Current floor: " + lift.getCurrentFloor());
 }
}